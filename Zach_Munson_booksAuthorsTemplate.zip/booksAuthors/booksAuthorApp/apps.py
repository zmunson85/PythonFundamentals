from django.apps import AppConfig


class BooksauthorappConfig(AppConfig):
    name = 'booksAuthorApp'
