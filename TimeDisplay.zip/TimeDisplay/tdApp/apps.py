from django.apps import AppConfig


class TdappConfig(AppConfig):
    name = 'tdApp'
