from django.apps import AppConfig


class UserregappConfig(AppConfig):
    name = 'userRegApp'
