from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('registration', views.new_user),
    path('success', views.success),
    path('login', views.login),
    path('login_success',views.login_success),
    path('logout',views.logout),
]
